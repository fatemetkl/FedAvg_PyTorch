to activate the env:
source py38/bin/activate 

to see the list of packages:
python -m pip list 


for lr 0.1 0.01 and 0.001 is used for optimization, optimized in one setting and used for all that network structure
for CNN best value -> 0.1
for 2NN -> 0.01


all the training data BATCHHH 60000
devided between 100 clients -> each 600 data examples